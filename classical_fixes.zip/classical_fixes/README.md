# classical_fixes
Picard Plugin to fix common classical music tagging problems
